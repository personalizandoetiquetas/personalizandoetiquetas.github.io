import { PRODUCTS_DATA } from './data.js';
import { formatCurrency } from './utils.js';

function toggleDropdown(id) {
    const menu  = document.getElementById(`menu-${id}`);
    const arrow = document.getElementById(`arrow-${id}`);
    const isOpen = menu.classList.contains("opacity-100");

    // Remove classe dropdown-open de todos os cards
    document.querySelectorAll('.product-card.dropdown-open').forEach(card => {
        card.classList.remove('dropdown-open');
    });

    // Fecha todos os dropdowns abertos
    document.querySelectorAll('[id^="menu-"]').forEach(m => {
        m.classList.remove("opacity-100", "scale-100");
        m.classList.add("opacity-0", "scale-95", "pointer-events-none");
    });
    document.querySelectorAll('[id^="arrow-"]').forEach(a => {
        a.style.transform = "rotate(0deg)";
    });
    document.querySelectorAll('.option-item').forEach(item => {
        item.classList.remove("opacity-100", "translate-y-0", "scale-100");
        item.classList.add("opacity-0", "translate-y-3", "scale-95");
        item.style.transitionDelay = "0ms";
    });

    if (!isOpen) {
        menu.classList.remove("opacity-0", "scale-95", "pointer-events-none");
        menu.classList.add("opacity-100", "scale-100");
        arrow.style.transform = "rotate(180deg)";

        // Adiciona classe ao product-card para elevar z-index
        const productCard = menu.closest('.product-card');
        if (productCard) {
            productCard.classList.add('dropdown-open');
        }

        menu.querySelectorAll(".option-item").forEach((item, index) => {
            item.style.transitionDelay = `${index * 60}ms`;
            requestAnimationFrame(() => {
                item.classList.remove("opacity-0", "translate-y-3", "scale-95");
                item.classList.add("opacity-100", "translate-y-0", "scale-100");
            });
        });
    }
}

function selectOption(productId, index) {
    const product = PRODUCTS_DATA.find(p => p.id === productId);
    const option  = product.options[index];

    const dropdown = document.getElementById(`dropdown-${productId}`);
    dropdown.dataset.selected = index;

    // Atualiza trigger — mantém o span do valor unitário
    document.getElementById(`selected-${productId}`).innerHTML =
        `${option.qtd} uni. <span class="dropdown-selected-unit">${formatCurrency(option.price / option.qtd)} uni.</span>`;

    document.getElementById(`selected-price-${productId}`).innerText = formatCurrency(option.price);
    document.getElementById(`price-${productId}`).innerText = formatCurrency(option.price);

    // Remove destaque antigo e aplica no novo
    document.querySelectorAll(`[id^="option-${productId}-"]`).forEach(el => {
        el.classList.remove('option-selected');
    });
    document.getElementById(`option-${productId}-${index}`).classList.add('option-selected');

    toggleDropdown(productId);
}

window.toggleDropdown = toggleDropdown;
window.selectOption   = selectOption;

export { toggleDropdown, selectOption };
