import { PRODUCTS_DATA, CATEGORIES, WHATSAPP_NUMBER, ACTIVE_CATEGORY } from "./data.js";
import { formatCurrency } from './utils.js';

let activeCategory = "";
let searchQuery    = "";

function init() {
    activeCategory = ACTIVE_CATEGORY;
    renderCategories();
    renderProducts();
    lucide.createIcons();
}

function renderCategories() {
    const container = document.getElementById('category-list');
    container.innerHTML = CATEGORIES.map(cat => `
        <button
            onclick="setCategory('${cat}')"
            class="cat-btn ${activeCategory === cat ? 'active' : ''}"
        >
            ${cat}
        </button>
    `).join('');

    document.getElementById('current-category-title').innerText =
        searchQuery ? `Resultados para "${searchQuery}"` : activeCategory;
}

function setCategory(cat) {
    activeCategory = cat;
    searchQuery    = "";
    const input = document.getElementById('search-input');
    const clear = document.getElementById('search-clear');
    if (input) input.value = "";
    if (clear) clear.classList.remove('visible');
    renderCategories();
    renderProducts();
}

function handleSearch(value) {
    searchQuery = value.trim();
    const clear = document.getElementById('search-clear');
    if (clear) clear.classList.toggle('visible', searchQuery.length > 0);
    renderCategories();
    renderProducts();
}

function clearSearch() {
    searchQuery = "";
    const input = document.getElementById('search-input');
    const clear = document.getElementById('search-clear');
    if (input) { input.value = ""; input.focus(); }
    if (clear) clear.classList.remove('visible');
    renderCategories();
    renderProducts();
}

function renderProducts() {
    const container = document.getElementById('products-grid');

    let filtered = searchQuery
        ? PRODUCTS_DATA.filter(p =>
            p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.specs.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.category.toLowerCase().includes(searchQuery.toLowerCase())
          )
        : PRODUCTS_DATA.filter(p => p.category === activeCategory);

    document.getElementById('item-count').innerText = `${filtered.length} ${filtered.length === 1 ? 'item' : 'itens'}`;

    if (filtered.length === 0) {
        container.innerHTML = searchQuery
            ? `<div class="search-empty">
                <strong>Nenhum resultado para "${searchQuery}"</strong>
                <span>Tente outro termo ou <button onclick="clearSearch()" style="background:none;border:none;color:var(--pink);font-weight:700;cursor:pointer;font-family:inherit;font-size:13px;">veja todos os produtos</button></span>
               </div>`
            : `<div class="products-empty"><p>Nenhum produto encontrado nesta categoria.</p></div>`;
        return;
    }

    container.innerHTML = filtered.map(product => {
        const firstOption = product.options[0];
        return `
        <div class="product-card">

            <div class="product-image-wrap" onclick="openImageModal(${product.id})">
                <img src="${product.image}" alt="${product.title}" loading="lazy">
                <div class="product-image-tag">
                    ${product.specs.split('•')[0].trim()}
                </div>
            </div>

            <div class="product-body">
                <h3 class="product-title">${highlightMatch(product.title, searchQuery)}</h3>
                <p class="product-specs">${product.specs}</p>

                <div class="product-actions">

                    <div class="dropdown-wrap" id="dropdown-${product.id}" data-selected="0">

                        <button type="button"
                            onclick="toggleDropdown(${product.id})"
                            class="dropdown-trigger">

                            <div class="dropdown-trigger-left">
                                <span id="selected-${product.id}" class="dropdown-selected-qty">
                                    ${firstOption.qtd} uni.
                                    <span class="dropdown-selected-unit">${formatCurrency(firstOption.price / firstOption.qtd)} uni.</span>
                                </span>
                            </div>

                            <div class="dropdown-trigger-right">
                                <span id="selected-price-${product.id}" class="dropdown-selected-price">
                                    ${formatCurrency(firstOption.price)}
                                </span>
                                <span id="arrow-${product.id}" class="dropdown-arrow">
                                    <i data-lucide="chevron-down"></i>
                                </span>
                            </div>
                        </button>

                        <div id="menu-${product.id}" class="dropdown-menu opacity-0 scale-95 pointer-events-none">
                            ${product.options.map((opt, idx) => `
                                <div onclick="selectOption(${product.id}, ${idx})"
                                     id="option-${product.id}-${idx}"
                                     class="option-item opacity-0 translate-y-3 scale-95">
                                    <span class="dropdown-selected-qty">${opt.qtd} uni.
                                        <span class="dropdown-selected-unit">${formatCurrency(opt.price / opt.qtd)} uni.</span>
                                    </span>
                                    <span style="font-weight:700;">${formatCurrency(opt.price)}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>

                    <div class="product-footer">
                        <div>
                            <div class="product-total-label">Valor Total</div>
                            <span id="price-${product.id}" class="product-total-price preco">${formatCurrency(firstOption.price)}</span>
                        </div>
                        <button onclick="addToCart(${product.id})" class="btn-add-cart" title="Adicionar ao carrinho">
                            <i data-lucide="shopping-cart"></i>
                        </button>
                    </div>

                </div>
            </div>
        </div>`;
    }).join('');

    lucide.createIcons();
}

// Destaca o termo buscado no título
function highlightMatch(text, query) {
    if (!query) return text;
    const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    return text.replace(regex, '<mark style="background:var(--pink-mid);color:var(--black);border-radius:2px;padding:0 2px;">$1</mark>');
}

window.init           = init;
window.renderCategories = renderCategories;
window.setCategory    = setCategory;
window.renderProducts = renderProducts;
window.handleSearch   = handleSearch;
window.clearSearch    = clearSearch;

export { init, renderCategories, setCategory, renderProducts, handleSearch, clearSearch };
