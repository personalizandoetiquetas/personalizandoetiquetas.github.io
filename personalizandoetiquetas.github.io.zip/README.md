# Personalizando Etiquetas

Site de vendas de etiquetas, tags e adesivos personalizados, com catálogo de produtos, carrinho de compras e finalização de pedido via WhatsApp.

---

## Sumário

- [Visão Geral](#visão-geral)
- [Estrutura de Arquivos](#estrutura-de-arquivos)
- [Arquitetura CSS](#arquitetura-css)
- [Arquitetura JS](#arquitetura-js)
- [Fluxo de Dados](#fluxo-de-dados)
- [Funcionalidades](#funcionalidades)
- [Como rodar localmente](#como-rodar-localmente)
- [Como adicionar produtos](#como-adicionar-produtos)
- [Dependências externas](#dependências-externas)

---

## Visão Geral

O site é composto por duas páginas principais:

| Página | Arquivo | Descrição |
|--------|---------|-----------|
| Home | `index.html` | Apresentação da marca, produto em destaque e seção "Como Funciona" |
| Catálogo | `catalogo/index.html` | Listagem de produtos por categoria, carrinho e checkout |

Não há backend. Todos os dados de produtos são lidos de um arquivo JSON estático, e o checkout é feito via link do WhatsApp com o resumo do pedido.

---

## Estrutura de Arquivos

```
/
├── index.html                  # Página inicial
├── products.json               # Base de dados dos produtos + configurações
├── catalogo/
│   └── index.html              # Página do catálogo
├── scripts/
│   ├── shared/                 (arquivos usados em mais de uma página)
│   │   ├── data.js             # loadData() + exports: PRODUCTS_DATA, CATEGORIES, FEATURED_PRODUCT_ID…
│   │   ├── cart.js             # Todo o estado e UI do carrinho (shared entre home e catálogo)
│   │   └── utils.js            # formatCurrency()
│   │
│   ├── home.js                 # Script exclusivo da home — produto em destaque, dropdown, add ao carrinho
│   ├── main.js                 # Ponto de entrada do catálogo
│   ├── products.js             # Renderização de categorias, cards, busca
│   ├── drop.js                 # Dropdown de opções dos cards do catálogo
│   ├── modal.js                # Modal de imagem do produto
│   └── toast.js                # Toast de confirmação
├── styles/
│   ├── style.css               # Ponto de entrada — apenas @imports
│   ├── base.css                # Reset, variáveis CSS, tipografia, utilitários
│   ├── animations.css          # Keyframes e transições
│   ├── home.css                # Estilos exclusivos da página inicial
│   ├── header.css              # Header do catálogo (banners, logo, botão carrinho)
│   ├── categories.css          # Barra de categorias e busca
│   ├── products.css            # Grid, cards, dropdown do catálogo
│   ├── cart.css                # Sidebar do carrinho
│   └── footer.css              # Rodapé e FAB
└── images/
    ├── logo-personalizandoetiquetas-redondo.png
    ├── tags-400x1320px.png
    ├── banner-3.png
    ├── como-funciona-1.png     # Imagens da seção "Como Funciona"
    ├── como-funciona-2.png
    ├── como-funciona-3.png
    ├── como-funciona-4.png
    └── produtos/
        ├── mini-tag-padrao.png
        ├── tag-retangular-padrao.png
        ├── tag-corte-especial.png
        └── cartao-visita-padrao.png
```

---

## Arquitetura CSS

O CSS está organizado em módulos independentes, cada um responsável por uma área específica do layout. O arquivo `styles/style.css` é o único importado nos HTMLs — ele reúne todos os outros via `@import`.

```css
/* styles/style.css */
@import './base.css';
@import './header.css';
@import './categories.css';
@import './products.css';
@import './cart.css';
@import './footer.css';
@import './animations.css';
```

### Módulos

| Arquivo | Responsabilidade |
|---------|-----------------|
| `base.css` | Variáveis CSS (cores, sombras, raios, transições), reset, tipografia, utilitários globais |
| `header.css` | Banner de frete, banner CTA WhatsApp, logo, botão do carrinho, header da home com imagem de fundo e estrelas animadas |
| `categories.css` | Barra de categorias com scroll horizontal, botão ativo/inativo, título e contador da categoria |
| `products.css` | Grid de produtos, cards, imagem com hover, dropdown de opções, botão adicionar, seção de produto principal e "Como Funciona" |
| `cart.css` | Modal overlay, sidebar com animação, header do carrinho, lista de itens, controles de quantidade, botão WhatsApp, estado vazio |
| `footer.css` | Rodapé e FAB (Floating Action Button) com badge de contagem |
| `animations.css` | Keyframes do toast, shine das estrelas, transições de entrada/saída, animações dos itens do carrinho |

### Variáveis CSS (definidas em `base.css`)

```css
--pink              /* #F03E7A — cor primária */
--pink-light        /* #FFF0F5 — fundo rosa claro */
--pink-mid          /* #FFD6E7 — rosa médio */
--gold              /* #FF8C0F — badge "mais vendido" */
--black             /* #111111 */
--gray-mid          /* #777777 — texto secundário */
--gray-light        /* #F5F5F5 — fundos neutros */
--gray-border       /* #E8E8E8 — bordas */
--green-wpp         /* #25D366 — botão WhatsApp */
--radius / --radius-sm / --radius-lg / --radius-full
--shadow / --shadow-sm / --shadow-lg / --shadow-pink
--transition / --transition-slow
```

### Breakpoints

As media queries ficam **dentro de cada arquivo CSS**, ao final, referentes apenas aos seus próprios elementos:

| Breakpoint | Uso |
|-----------|-----|
| `max-width: 400px` | Grid de 1 coluna em telas muito pequenas |
| `max-width: 640px` | Mobile — ajustes de layout, header da home, grid "Como Funciona" em 2 colunas |
| `min-width: 768px` | Desktop — grid de produtos em 3 colunas |

---

## Arquitetura JS

Todos os scripts do catálogo usam **ES Modules** (`type="module"`). O `main.js` é o único importado no HTML e orquestra os demais.

### Módulos

#### `data.js`
- Faz `fetch('/products.json')` e exporta as variáveis globais:
  - `PRODUCTS_DATA` — array de produtos
  - `CATEGORIES` — array de strings das categorias
  - `WHATSAPP_NUMBER` — número de contato
  - `ACTIVE_CATEGORY` — categoria selecionada por padrão

#### `products.js`
- `init()` — inicializa categorias e produtos
- `renderCategories()` — injeta os botões de categoria no `#category-list`
- `setCategory(cat)` — troca a categoria ativa e re-renderiza
- `renderProducts()` — filtra `PRODUCTS_DATA` pela categoria ativa e injeta os cards no `#products-grid`

Cada card gerado contém:
- Imagem clicável (abre modal)
- Título e specs
- Dropdown de opções (`#dropdown-{id}`, `#menu-{id}`)
- Preços dinâmicos (`#selected-{id}`, `#selected-price-{id}`, `#price-{id}`)
- Botão de adicionar ao carrinho

#### `drop.js`
- `toggleDropdown(id)` — abre/fecha o menu de opções de um produto, fechando todos os outros
- `selectOption(productId, index)` — atualiza os elementos de preço do card ao selecionar uma opção e salva o índice no `data-selected` do dropdown

#### `cart.js`
- `addToCart(productId)` — lê o `data-selected` do dropdown e adiciona ao carrinho; agrupa automaticamente se o mesmo produto+opção já existir (incrementa `quantity`)
- `removeFromCart(cartId)` — remove item pelo `cartId` único
- `changeQuantity(cartId, delta)` — incrementa ou decrementa a quantidade; remove o item se chegar a zero (com confirmação)
- `clearCart()` — esvazia o carrinho (com confirmação)
- `updateCartUI()` — re-renderiza toda a interface do carrinho (badges, lista, total, estados)
- `toggleCart(show)` — abre/fecha o modal do carrinho alternando as classes `cart-visible` / `cart-hidden`
- `checkoutWhatsApp()` — monta a mensagem formatada com todos os itens e abre o link `wa.me`
- `saveCartToStorage()` / `loadCartFromStorage()` — persiste o carrinho no `localStorage` com a chave `meuCarrinhoCompras`

#### `modal.js`
- `setupImageModal()` — injeta o HTML do modal de imagem no `<body>` (executado uma vez no carregamento)
- `openImageModal(productId)` — preenche o modal com os dados do produto e exibe
- `closeImageModal(event)` / `forceCloseModal()` — fecha o modal

#### `toast.js`
- `showAddedToast()` — exibe o toast de confirmação com barra de progresso de 6 segundos e botões "Abrir Carrinho" / "Continuar Comprando"
- `hideToast()` — remove o toast com animação de saída

#### `utils.js`
- `formatCurrency(value)` — formata um número para `R$ 0,00` usando `Intl.NumberFormat` com arredondamento para cima (`Math.ceil`)

#### `principal-prices.js`
- Exclusivo da `index.html`
- `initPrincipalProduct()` — carrega os dados e renderiza o dropdown do produto em destaque
- `addPrincipalProductToCart()` — adiciona o produto ao `localStorage` e redireciona para `/catalogo`, onde o carrinho será aberto automaticamente via `sessionStorage`
- Redefine `toggleDropdown` e `selectOption` localmente (versão simplificada, sem animação de itens)

---

## Fluxo de Dados

```
products.json
     │
     ▼
data.js (fetch + exporta variáveis)
     │
     ▼
main.js (importa tudo e chama loadData → init)
     │
     ├── products.js → renderiza categorias e cards no DOM
     ├── cart.js → carrega carrinho do localStorage e atualiza UI
     ├── modal.js → injeta modal de imagem no body
     └── drop.js → funções do dropdown expostas globalmente
```

### Fluxo do checkout

```
Usuário clica "Adicionar ao carrinho"
     │
     ▼
addToCart(productId)
  └── lê data-selected do dropdown
  └── agrupa se já existe, senão push
  └── saveCartToStorage()
  └── updateCartUI()
  └── showAddedToast()
     │
     ▼
Usuário clica "Enviar Pedido no WhatsApp"
     │
     ▼
checkoutWhatsApp()
  └── monta mensagem formatada
  └── window.open(wa.me/...)
```

### Fluxo home → catálogo (produto em destaque)

```
Usuário clica "Adicionar ao Carrinho" na home
     │
     ▼
addPrincipalProductToCart()
  └── salva item no localStorage
  └── sessionStorage.setItem("openCart", "1")
  └── redireciona para /catalogo
     │
     ▼
cart.js (window load)
  └── lê sessionStorage "openCart"
  └── chama toggleCart(true) após 300ms
```

---

## Funcionalidades

- **Catálogo por categorias** — filtro por Tags, Cartões, Adesivos, Outros
- **Dropdown de opções** — cada produto tem múltiplas opções de quantidade/preço com animação de entrada
- **Carrinho persistente** — salvo no `localStorage`, sobrevive a recarregamentos
- **Agrupamento automático** — adicionar o mesmo produto+opção incrementa a quantidade em vez de duplicar o item
- **Controle de quantidade** — botões +/− no carrinho com remoção ao zerar
- **Modal de imagem** — clique na foto do produto para ampliar
- **Toast de confirmação** — notificação ao adicionar item com barra de progresso
- **Checkout WhatsApp** — mensagem formatada com todos os itens, quantidades e total
- **Abertura automática do carrinho** — ao voltar da home após adicionar produto em destaque
- **Responsivo** — layout adaptado para mobile (400px), tablet (640px) e desktop (768px+)

---

## Como rodar localmente

O projeto usa `fetch('/products.json')`, então precisa de um servidor HTTP (não funciona abrindo o HTML diretamente no navegador via `file://`).

**Opção 1 — VS Code Live Server**
Instale a extensão "Live Server" e clique em "Go Live".

**Opção 2 — Python**
```bash
python3 -m http.server 8080
```
Acesse `http://localhost:8080`

**Opção 3 — Node.js**
```bash
npx serve .
```

---

## Como adicionar produtos

Edite o arquivo `products.json` seguindo a estrutura:

```json
{
  "id": 6,
  "category": "Adesivos",
  "title": "Nome do produto",
  "image": "/images/produtos/nome-do-arquivo.png",
  "specs": "Dimensões • Acabamento • Material",
  "options": [
    { "qtd": 100, "price": 49.90, "label": "" },
    { "qtd": 500, "price": 149.90, "label": "MAIS VENDIDO" },
    { "qtd": 1000, "price": 249.90, "label": "Economize R$50,00" }
  ]
}
```

> Para trocar o produto em destaque da home, basta mudar o `FEATURED_PRODUCT_ID` no `products.json`:
> ```json
> "FEATURED_PRODUCT_ID": 3
> ```
> O `home.js` vai buscar automaticamente o produto com aquele `id` e preencher toda a seção.

> **`label`** aceita três formatos reconhecidos pelo sistema:
> - `"MAIS VENDIDO"` — badge laranja com estrela
> - `"Economize R$X,00"` — texto verde
> - Qualquer outro texto — exibido em cinza

Para adicionar uma nova **categoria**, inclua a string no array `CATEGORIES` do `products.json`:

```json
"CATEGORIES": ["Tags", "Cartões", "Adesivos", "Outros", "Nova Categoria"]
```

---

## Dependências externas

| Dependência | Uso | CDN |
|------------|-----|-----|
| **Lucide Icons** | Ícones SVG (carrinho, caminhão, x, etc.) | `https://unpkg.com/lucide@latest` |
| **Inter (Google Fonts)** | Fonte principal do site | `https://fonts.googleapis.com` |
| **Material Icons Outlined** | Ícones de estrela na home | `https://fonts.googleapis.com/icon` |

> Nenhuma dependência de CSS de terceiros — o projeto usa CSS puro modular, sem Tailwind ou frameworks.
